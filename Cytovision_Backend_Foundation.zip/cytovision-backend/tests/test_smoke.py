from fastapi.testclient import TestClient
from app.main import app

def test_health():
    with TestClient(app) as client:
        response=client.get("/v1/health")
        assert response.status_code==200
        assert response.json()["status"] in {"ok","degraded"}

def test_root():
    with TestClient(app) as client:
        assert client.get("/").json()["service"]=="Cytovision Backend"
