# Cytovision Backend — platform foundation

This is a deployable FastAPI backend scaffold aligned to the HistocyAi/Cytovision frontend workflows. It is a research-use workflow service, not a clinically validated diagnostic device.

## Included
- Email/password registration, login, JWT access and refresh tokens
- Laboratory organizations and memberships
- Organization-scoped cases and pseudonymous patient references
- Image upload, SHA-256 duplicate detection and authenticated image retrieval (local development storage)
- Case annotations and pathologist review permissions
- AI job request/status endpoints with explicit `unavailable` state until a validated model adapter is installed
- Consultations, case-linked conversations and messages
- Offline sync event journal with idempotency key
- Organization-scoped audit events and admin metrics
- WebSocket connection/authentication handshake
- PostgreSQL, Redis and Docker Compose

## Run locally
1. Copy `.env.example` to `.env`.
2. Change `JWT_SECRET` and database credentials.
3. Run `docker compose up --build`.
4. Open `http://localhost:8000/docs`; health check is `/v1/health`.

For local Python development, install `requirements.txt`, set `DATABASE_URL=sqlite:///./cytovision.db`, then run `uvicorn app.main:app --reload`.

## First user
`POST /v1/register` creates the first user and a laboratory with a cytotechnologist membership. A lab administrator must be provisioned by a trusted platform administrator before production onboarding; do not expose an unauthenticated role-elevation endpoint.

Optional bootstrap platform admin: set `BOOTSTRAP_ADMIN_EMAIL` and `BOOTSTRAP_ADMIN_PASSWORD` before first start. Keep these secrets out of source control.

## Core API
- `POST /v1/register`, `POST /v1/login`, `POST /v1/token/refresh`, `GET /v1/me`
- `GET/POST /v1/cases`, `GET /v1/cases/{id}`, `PATCH /v1/cases/{id}`
- `POST /v1/cases/{id}/images`, `GET /v1/images/{id}/content`
- `POST /v1/cases/{id}/annotations`, `POST /v1/cases/{id}/reviews`
- `POST /v1/analyze` and `/v1/case/analyze`, `GET /v1/ai/jobs/{id}`
- `GET/POST /v1/consults`
- `GET/POST /v1/conversations`, `GET/POST /v1/conversations/{id}/messages`
- `POST/GET /v1/sync`
- `GET /v1/admin/audit`, `GET /v1/admin/metrics`
- `WS /ws?token=<access-token>`

## Important integration notes
- The frontend has configurable placeholder service URLs (including `your-cytovision-host.onrender.com`, `your-server.example`, `sync.example.org`, and `project.supabase.co`). Replace these in the client settings with the deployed API origin only after deployment and TLS are configured.
- This backend intentionally does not fake AI outputs. The inference endpoint creates a job marked `unavailable` while `AI_PROVIDER=disabled`. Implement a separately tested adapter for each actual YOLO / CellViT++ / classifier artifact, record model checksum/version and calibration metadata, and only then enable inference.
- The current sync endpoint journals and deduplicates client events; it does not blindly overwrite clinical records. Entity-specific conflict resolution, tombstones, and replay handlers must be implemented before relying on sync for clinical records.
- WebSocket currently provides authenticated connection and acknowledgements; fan-out, presence, delivery receipts, push notifications and call signaling require Redis pub/sub and provider credentials.
- `STORAGE_MODE=local` is for development only. For production, implement S3-compatible storage with private buckets, encryption, malware scanning and short-lived signed URLs.
- Startup `create_all` is development bootstrap only. Production requires Alembic migrations, backup/restore tests, monitoring and secret management.
- Add rate limiting, account verification, password reset, token revocation/rotation, MFA, device management, structured security logging and data-retention policies before handling real patient data.
- Restrict CORS to exact production origins. Never put service secrets or private API keys in the APK.
- The app should remain marked research use only until clinical validation, ethics and applicable regulatory approvals are complete.

## Security boundary
All patient/case/image resources are scoped to the user's active organization. New accounts are not verified and receive only a cytotechnologist membership. Pathologist review is server-side role-gated. Do not use real patient identifiers in development.
