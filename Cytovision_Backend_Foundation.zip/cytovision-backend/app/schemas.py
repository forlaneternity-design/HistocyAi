from pydantic import BaseModel, EmailStr, Field, ConfigDict
from typing import Any

class RegisterIn(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=160)
    password: str = Field(min_length=12, max_length=128)
    organization_name: str = Field(min_length=2, max_length=180)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: dict

class CaseIn(BaseModel):
    accession_number: str = Field(min_length=1, max_length=120)
    specimen_type: str = Field(min_length=2, max_length=120)
    external_patient_ref: str | None = Field(default=None, max_length=120)
    clinical_note: str | None = Field(default=None, max_length=10000)

class ReviewIn(BaseModel):
    decision: str = Field(pattern="^(needs_review|accepted|rejected|amended)$")
    comment: str | None = Field(default=None, max_length=10000)

class AnnotationIn(BaseModel):
    image_id: str | None = None
    kind: str = Field(min_length=1, max_length=60)
    geometry: dict[str, Any] = Field(default_factory=dict)
    body: str | None = Field(default=None, max_length=10000)

class ConsultationIn(BaseModel):
    case_id: str
    specialist_id: str | None = None
    note: str | None = Field(default=None, max_length=10000)

class ConversationIn(BaseModel):
    title: str = Field(default="Case discussion", max_length=180)
    case_id: str | None = None
    member_ids: list[str] = Field(default_factory=list)

class MessageIn(BaseModel):
    body: str = Field(min_length=1, max_length=10000)

class SyncIn(BaseModel):
    client_event_id: str = Field(min_length=1, max_length=120)
    entity_type: str = Field(min_length=1, max_length=60)
    entity_id: str = Field(min_length=1, max_length=36)
    operation: str = Field(pattern="^(upsert|delete)$")
    payload: dict = Field(default_factory=dict)
