from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator
from typing import List

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_name: str = "Cytovision Backend"
    environment: str = "development"
    api_prefix: str = "/v1"
    database_url: str = "sqlite:///./cytovision.db"
    jwt_secret: str = "development-only-change-this-secret-before-deploying"
    jwt_issuer: str = "cytovision"
    access_token_minutes: int = 20
    refresh_token_days: int = 14
    cors_origins: str = "http://localhost:3000,http://localhost:8100,capacitor://localhost"
    storage_mode: str = "local"
    local_storage_path: str = "./data/uploads"
    max_upload_bytes: int = 25_000_000
    ai_provider: str = "disabled"
    ai_model_version: str = "not-configured"
    redis_url: str = "redis://localhost:6379/0"
    bootstrap_admin_email: str = ""
    bootstrap_admin_password: str = ""

    @property
    def cors_origin_list(self) -> List[str]:
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

settings = Settings()
