from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from pwdlib import PasswordHash
from .config import settings

password_hash = PasswordHash.recommended()
ALGORITHM = "HS256"

def hash_password(password: str) -> str:
    if len(password) < 12:
        raise ValueError("Password must be at least 12 characters")
    return password_hash.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    try: return password_hash.verify(password, hashed)
    except Exception: return False

def create_token(subject: str, token_type: str = "access", minutes: int | None = None) -> str:
    now = datetime.now(timezone.utc)
    exp = now + (timedelta(minutes=minutes) if minutes else timedelta(days=settings.refresh_token_days) if token_type == "refresh" else timedelta(minutes=settings.access_token_minutes))
    return jwt.encode({"sub": subject, "type": token_type, "iss": settings.jwt_issuer, "iat": now, "exp": exp}, settings.jwt_secret, algorithm=ALGORITHM)

def decode_token(token: str, expected_type: str = "access") -> str:
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[ALGORITHM], issuer=settings.jwt_issuer)
        if payload.get("type") != expected_type or not payload.get("sub"): raise ValueError("Invalid token type")
        return payload["sub"]
    except (JWTError, ValueError) as exc:
        raise ValueError("Invalid or expired token") from exc
