import hashlib, os, uuid, json
from pathlib import Path
from datetime import datetime, timezone
from typing import Annotated
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Header, WebSocket, WebSocketDisconnect, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from .config import settings
from .db import Base, engine, get_db, SessionLocal
from . import models as m
from .schemas import RegisterIn, LoginIn, CaseIn, ReviewIn, AnnotationIn, ConsultationIn, ConversationIn, MessageIn, SyncIn
from .security import hash_password, verify_password, create_token, decode_token

app = FastAPI(title=settings.app_name, version="1.0.0", description="Cytovision research workflow API. AI outputs require separately validated model deployments.")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origin_list, allow_credentials=True, allow_methods=["GET","POST","PATCH","DELETE","OPTIONS"], allow_headers=["Authorization","Content-Type","X-Client-Event-ID"])
oauth2 = OAuth2PasswordBearer(tokenUrl=f"{settings.api_prefix}/login")

@app.on_event("startup")
def startup():
    # create_all is for local bootstrap only; production deployments should use versioned migrations.
    Base.metadata.create_all(bind=engine)
    if settings.bootstrap_admin_email and settings.bootstrap_admin_password:
        with SessionLocal() as db:
            email = settings.bootstrap_admin_email.lower()
            if not db.scalar(select(m.User).where(m.User.email == email)):
                user = m.User(email=email, full_name="Platform Administrator", password_hash=hash_password(settings.bootstrap_admin_password), platform_role="platform_admin", is_verified=True)
                db.add(user); db.commit()

def audit(db: Session, actor, action, resource_type, resource_id=None, org_id=None, detail=None):
    db.add(m.AuditEvent(actor_id=actor.id if actor else None, organization_id=org_id, action=action, resource_type=resource_type, resource_id=resource_id, detail=detail or {}))

def current_user(token: Annotated[str, Depends(oauth2)], db: Session = Depends(get_db)):
    try: uid = decode_token(token, "access")
    except ValueError: raise HTTPException(401, "Invalid or expired access token", headers={"WWW-Authenticate":"Bearer"})
    user = db.get(m.User, uid)
    if not user or not user.is_active: raise HTTPException(401, "Account unavailable")
    return user

def org_context(user: m.User, db: Session):
    membership = db.scalar(select(m.Membership).where(m.Membership.user_id==user.id, m.Membership.active==True).limit(1))
    if not membership: raise HTTPException(403, "No active laboratory membership")
    return membership

def require_role(*roles):
    def check(user: m.User = Depends(current_user), db: Session = Depends(get_db)):
        membership = org_context(user, db)
        if membership.role not in roles and user.platform_role != "platform_admin":
            raise HTTPException(403, "Insufficient laboratory role")
        return (user, membership)
    return check

def case_in_org(db, case_id, org_id):
    obj = db.get(m.Case, case_id)
    if not obj or obj.organization_id != org_id: raise HTTPException(404, "Case not found")
    return obj

@app.get("/health")
@app.get(settings.api_prefix + "/health")
def health(db: Session = Depends(get_db)):
    try:
        db.execute(select(1))
        database = "ok"
    except Exception: database = "unavailable"
    return {"status":"ok" if database=="ok" else "degraded","database":database,"ai":{"status":"disabled" if settings.ai_provider=="disabled" else "configured","model_version":settings.ai_model_version},"version":"1.0.0"}

@app.post(settings.api_prefix + "/register", status_code=201)
def register(data: RegisterIn, db: Session=Depends(get_db)):
    email=data.email.lower()
    if db.scalar(select(m.User).where(m.User.email==email)): raise HTTPException(409,"Email already registered")
    try: pw=hash_password(data.password)
    except ValueError as e: raise HTTPException(422,str(e))
    user=m.User(email=email,full_name=data.full_name,password_hash=pw)
    org=m.Organization(name=data.organization_name)
    db.add_all([user,org]); db.flush()
    db.add(m.Membership(user_id=user.id,organization_id=org.id,role="cytotechnologist"))
    audit(db,user,"account.registered","user",user.id,org.id)
    db.commit()
    return {"id":user.id,"email":user.email,"full_name":user.full_name,"organization_id":org.id,"role":"cytotechnologist","verification_required":True}

@app.post(settings.api_prefix + "/login")
def login(data: LoginIn, db: Session=Depends(get_db)):
    user=db.scalar(select(m.User).where(m.User.email==data.email.lower()))
    if not user or not verify_password(data.password,user.password_hash): raise HTTPException(401,"Incorrect email or password")
    if not user.is_active: raise HTTPException(403,"Account disabled")
    audit(db,user,"account.login","user",user.id); db.commit()
    return {"access_token":create_token(user.id),"refresh_token":create_token(user.id,"refresh"),"token_type":"bearer","user":{"id":user.id,"email":user.email,"full_name":user.full_name,"platform_role":user.platform_role}}

@app.post(settings.api_prefix + "/token/refresh")
def refresh(refresh_token: Annotated[str, Header(alias="X-Refresh-Token")], db: Session=Depends(get_db)):
    try: uid=decode_token(refresh_token,"refresh")
    except ValueError: raise HTTPException(401,"Invalid refresh token")
    user=db.get(m.User,uid)
    if not user or not user.is_active: raise HTTPException(401,"Account unavailable")
    return {"access_token":create_token(uid),"refresh_token":create_token(uid,"refresh"),"token_type":"bearer"}

@app.post(settings.api_prefix + "/logout")
def logout(user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    audit(db,user,"account.logout","user",user.id); db.commit()
    return {"status":"ok","message":"Discard client tokens. Server-side token revocation requires a configured token denylist."}

@app.get(settings.api_prefix + "/me")
def me(user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    mem=org_context(user,db)
    return {"id":user.id,"email":user.email,"full_name":user.full_name,"platform_role":user.platform_role,"organization_id":mem.organization_id,"role":mem.role}

@app.post(settings.api_prefix + "/organizations")
def create_org(name: str, user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    org=m.Organization(name=name); db.add(org); db.flush()
    db.add(m.Membership(user_id=user.id,organization_id=org.id,role="lab_admin"))
    audit(db,user,"organization.created","organization",org.id,org.id); db.commit()
    return {"id":org.id,"name":org.name}

@app.get(settings.api_prefix + "/cases")
def list_cases(user: m.User=Depends(current_user), db: Session=Depends(get_db), limit: int=50, offset: int=0):
    mem=org_context(user,db)
    rows=db.scalars(select(m.Case).where(m.Case.organization_id==mem.organization_id).order_by(desc(m.Case.created_at)).offset(offset).limit(min(limit,100))).all()
    return [{"id":x.id,"accession_number":x.accession_number,"specimen_type":x.specimen_type,"status":x.status,"patient_id":x.patient_id,"created_at":x.created_at} for x in rows]

@app.post(settings.api_prefix + "/cases", status_code=201)
def create_case(data: CaseIn, user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    mem=org_context(user,db)
    if db.scalar(select(m.Case).where(m.Case.organization_id==mem.organization_id,m.Case.accession_number==data.accession_number)): raise HTTPException(409,"Accession number already exists")
    patient=None
    if data.external_patient_ref:
        patient=db.scalar(select(m.Patient).where(m.Patient.organization_id==mem.organization_id,m.Patient.external_ref==data.external_patient_ref))
        if not patient:
            patient=m.Patient(organization_id=mem.organization_id,external_ref=data.external_patient_ref); db.add(patient); db.flush()
    case=m.Case(organization_id=mem.organization_id,patient_id=patient.id if patient else None,accession_number=data.accession_number,specimen_type=data.specimen_type,clinical_note=data.clinical_note,created_by=user.id)
    db.add(case); db.flush(); audit(db,user,"case.created","case",case.id,mem.organization_id); db.commit()
    return {"id":case.id,"accession_number":case.accession_number,"status":case.status}

@app.get(settings.api_prefix + "/cases/{case_id}")
def get_case(case_id: str, user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    mem=org_context(user,db); c=case_in_org(db,case_id,mem.organization_id)
    imgs=db.scalars(select(m.ImageAsset).where(m.ImageAsset.case_id==c.id)).all()
    return {"id":c.id,"accession_number":c.accession_number,"specimen_type":c.specimen_type,"status":c.status,"clinical_note":c.clinical_note,"images":[{"id":i.id,"name":i.original_name,"mime_type":i.mime_type,"size_bytes":i.size_bytes} for i in imgs]}

@app.patch(settings.api_prefix + "/cases/{case_id}")
def update_case(case_id: str, status_value: str, user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    mem=org_context(user,db); c=case_in_org(db,case_id,mem.organization_id)
    allowed={"registered","received","processing","awaiting_review","completed","cancelled"}
    if status_value not in allowed: raise HTTPException(422,"Invalid case status")
    c.status=status_value; audit(db,user,"case.status_changed","case",c.id,mem.organization_id,{"status":status_value}); db.commit()
    return {"id":c.id,"status":c.status}

@app.post(settings.api_prefix + "/cases/{case_id}/images", status_code=201)
async def upload_image(case_id: str, file: UploadFile=File(...), user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    mem=org_context(user,db); case_in_org(db,case_id,mem.organization_id)
    if file.content_type not in {"image/jpeg","image/png","image/tiff","image/webp"}: raise HTTPException(415,"Unsupported image type")
    data=await file.read(settings.max_upload_bytes+1)
    if len(data)>settings.max_upload_bytes: raise HTTPException(413,"Image exceeds upload limit")
    if not data: raise HTTPException(400,"Empty upload")
    digest=hashlib.sha256(data).hexdigest()
    existing=db.scalar(select(m.ImageAsset).where(m.ImageAsset.organization_id==mem.organization_id,m.ImageAsset.sha256==digest,m.ImageAsset.case_id==case_id))
    if existing: return {"id":existing.id,"duplicate":True,"sha256":digest}
    key=f"{mem.organization_id}/{case_id}/{uuid.uuid4().hex}"
    if settings.storage_mode!="local": raise HTTPException(503,"Object storage adapter is not configured; refusing unsafe fallback")
    path=Path(settings.local_storage_path); path.mkdir(parents=True,exist_ok=True)
    target=path/key; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
    asset=m.ImageAsset(organization_id=mem.organization_id,case_id=case_id,object_key=key,original_name=(file.filename or "image")[:255],mime_type=file.content_type,size_bytes=len(data),sha256=digest,uploaded_by=user.id)
    db.add(asset); db.flush(); audit(db,user,"image.uploaded","image",asset.id,mem.organization_id,{"sha256":digest,"bytes":len(data)}); db.commit()
    return {"id":asset.id,"sha256":digest,"size_bytes":len(data),"duplicate":False}

@app.get(settings.api_prefix + "/images/{image_id}/content")
def image_content(image_id: str, user: m.User=Depends(current_user), db: Session=Depends(get_db)):
    from fastapi.responses import FileResponse
    mem=org_context(user,db); img=db.get(m.ImageAsset,image_id)
    if not img or img.organization_id!=mem.organization_id: raise HTTPException(404,"Image not found")
    if settings.storage_mode!="local": raise HTTPException(503,"Object storage adapter not configured")
    path=Path(settings.local_storage_path)/img.object_key
    if not path.is_file(): raise HTTPException(404,"Image bytes unavailable")
    return FileResponse(path,media_type=img.mime_type,filename=img.original_name)

@app.post(settings.api_prefix + "/cases/{case_id}/annotations",status_code=201)
def add_annotation(case_id: str,data: AnnotationIn,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db); case_in_org(db,case_id,mem.organization_id)
    if data.image_id:
        img=db.get(m.ImageAsset,data.image_id)
        if not img or img.organization_id!=mem.organization_id or img.case_id!=case_id: raise HTTPException(404,"Image not found in case")
    a=m.Annotation(organization_id=mem.organization_id,case_id=case_id,image_id=data.image_id,author_id=user.id,kind=data.kind,geometry=data.geometry,body=data.body)
    db.add(a); db.flush(); audit(db,user,"annotation.created","annotation",a.id,mem.organization_id); db.commit()
    return {"id":a.id,"created_at":a.created_at}

@app.post(settings.api_prefix + "/cases/{case_id}/reviews",status_code=201)
def add_review(case_id: str,data: ReviewIn,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db)
    if mem.role not in {"pathologist","lab_admin"} and user.platform_role!="platform_admin": raise HTTPException(403,"Pathologist review role required")
    case=case_in_org(db,case_id,mem.organization_id)
    r=m.Review(organization_id=mem.organization_id,case_id=case_id,reviewer_id=user.id,decision=data.decision,comment=data.comment)
    db.add(r)
    if data.decision=="accepted": case.status="completed"
    elif data.decision=="needs_review": case.status="awaiting_review"
    audit(db,user,"case.reviewed","case",case_id,mem.organization_id,{"decision":data.decision}); db.commit()
    return {"id":r.id,"decision":r.decision,"case_status":case.status}

@app.post(settings.api_prefix + "/case/analyze")
@app.post(settings.api_prefix + "/analyze")
def analyze(payload: dict,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db)
    case_id=payload.get("case_id")
    if not case_id: raise HTTPException(422,"case_id is required")
    case_in_org(db,case_id,mem.organization_id)
    image_ids=payload.get("image_ids") or ([payload["image_id"]] if payload.get("image_id") else [])
    if not image_ids: raise HTTPException(422,"At least one image_id is required")
    for iid in image_ids:
        img=db.get(m.ImageAsset,iid)
        if not img or img.case_id!=case_id or img.organization_id!=mem.organization_id: raise HTTPException(404,"Image not found in case")
    job=m.AIJob(organization_id=mem.organization_id,case_id=case_id,image_ids=image_ids,model_version=settings.ai_model_version,requested_by=user.id,status="unavailable" if settings.ai_provider=="disabled" else "queued",failure_reason="No validated inference adapter/model is configured" if settings.ai_provider=="disabled" else None)
    db.add(job); db.flush(); audit(db,user,"ai.analysis_requested","ai_job",job.id,mem.organization_id,{"image_count":len(image_ids)}); db.commit()
    return {"job_id":job.id,"status":job.status,"model_version":job.model_version,"result":None,"message":"AI inference is not configured. No diagnostic result has been generated." if job.status=="unavailable" else "Job queued for configured worker."}

@app.get(settings.api_prefix + "/ai/jobs/{job_id}")
def get_ai_job(job_id: str,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db); job=db.get(m.AIJob,job_id)
    if not job or job.organization_id!=mem.organization_id: raise HTTPException(404,"Job not found")
    return {"id":job.id,"status":job.status,"model_version":job.model_version,"result":job.result_json,"failure_reason":job.failure_reason}

@app.post(settings.api_prefix + "/consults",status_code=201)
@app.post(settings.api_prefix + "/consultations",status_code=201)
def create_consult(data: ConsultationIn,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db); case_in_org(db,data.case_id,mem.organization_id)
    if data.specialist_id:
        membership=db.scalar(select(m.Membership).where(m.Membership.user_id==data.specialist_id,m.Membership.organization_id==mem.organization_id,m.Membership.active==True))
        if not membership or membership.role not in {"pathologist","lab_admin"}: raise HTTPException(404,"Specialist not found")
    c=m.Consultation(organization_id=mem.organization_id,case_id=data.case_id,requested_by=user.id,specialist_id=data.specialist_id,note=data.note)
    db.add(c); db.flush(); audit(db,user,"consultation.requested","consultation",c.id,mem.organization_id); db.commit()
    return {"id":c.id,"status":c.status}

@app.get(settings.api_prefix + "/consults")
def list_consults(user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db); rows=db.scalars(select(m.Consultation).where(m.Consultation.organization_id==mem.organization_id).order_by(desc(m.Consultation.created_at)).limit(100)).all()
    return [{"id":x.id,"case_id":x.case_id,"status":x.status,"requested_by":x.requested_by,"specialist_id":x.specialist_id,"note":x.note} for x in rows]

@app.post(settings.api_prefix + "/conversations",status_code=201)
def create_conversation(data: ConversationIn,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db)
    if data.case_id: case_in_org(db,data.case_id,mem.organization_id)
    ids=set(data.member_ids+[user.id])
    for uid in ids:
        if not db.scalar(select(m.Membership).where(m.Membership.user_id==uid,m.Membership.organization_id==mem.organization_id,m.Membership.active==True)): raise HTTPException(422,"All conversation members must belong to this laboratory")
    c=m.Conversation(organization_id=mem.organization_id,title=data.title,case_id=data.case_id,created_by=user.id); db.add(c); db.flush()
    db.add_all([m.ConversationMember(conversation_id=c.id,user_id=uid) for uid in ids])
    audit(db,user,"conversation.created","conversation",c.id,mem.organization_id); db.commit()
    return {"id":c.id,"title":c.title,"case_id":c.case_id}

def conversation_access(db,user,cid):
    c=db.get(m.Conversation,cid)
    if not c or not db.scalar(select(m.ConversationMember).where(m.ConversationMember.conversation_id==cid,m.ConversationMember.user_id==user.id)): raise HTTPException(404,"Conversation not found")
    return c

@app.get(settings.api_prefix + "/conversations")
def list_conversations(user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    ids=select(m.ConversationMember.conversation_id).where(m.ConversationMember.user_id==user.id)
    rows=db.scalars(select(m.Conversation).where(m.Conversation.id.in_(ids)).order_by(desc(m.Conversation.created_at))).all()
    return [{"id":x.id,"title":x.title,"case_id":x.case_id} for x in rows]

@app.get(settings.api_prefix + "/conversations/{conversation_id}/messages")
def get_messages(conversation_id: str,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    conversation_access(db,user,conversation_id)
    rows=db.scalars(select(m.Message).where(m.Message.conversation_id==conversation_id).order_by(m.Message.created_at).limit(200)).all()
    return [{"id":x.id,"sender_id":x.sender_id,"body":x.body,"created_at":x.created_at} for x in rows]

@app.post(settings.api_prefix + "/conversations/{conversation_id}/messages",status_code=201)
def send_message(conversation_id: str,data: MessageIn,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    conversation_access(db,user,conversation_id)
    msg=m.Message(conversation_id=conversation_id,sender_id=user.id,body=data.body); db.add(msg); db.commit()
    return {"id":msg.id,"created_at":msg.created_at}

@app.post(settings.api_prefix + "/sync")
def sync_event(data: SyncIn,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db)
    existing=db.scalar(select(m.SyncEvent).where(m.SyncEvent.organization_id==mem.organization_id,m.SyncEvent.client_event_id==data.client_event_id))
    if existing: return {"id":existing.id,"duplicate":True,"status":"already_applied"}
    event=m.SyncEvent(organization_id=mem.organization_id,user_id=user.id,client_event_id=data.client_event_id,entity_type=data.entity_type,entity_id=data.entity_id,operation=data.operation,payload=data.payload)
    db.add(event); audit(db,user,"sync.event_received","sync_event",event.id,mem.organization_id,{"entity_type":data.entity_type,"operation":data.operation}); db.commit()
    return {"id":event.id,"duplicate":False,"status":"accepted","note":"Event journaled; entity-specific conflict-aware application is a follow-on adapter."}

@app.get(settings.api_prefix + "/sync")
def sync_pull(since: str | None=None,user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db)
    q=select(m.SyncEvent).where(m.SyncEvent.organization_id==mem.organization_id).order_by(m.SyncEvent.created_at).limit(500)
    rows=db.scalars(q).all()
    return [{"id":x.id,"client_event_id":x.client_event_id,"entity_type":x.entity_type,"entity_id":x.entity_id,"operation":x.operation,"payload":x.payload,"created_at":x.created_at} for x in rows]

@app.get(settings.api_prefix + "/admin/audit")
def audit_log(user: m.User=Depends(current_user),db: Session=Depends(get_db),limit: int=100):
    mem=org_context(user,db)
    if mem.role!="lab_admin" and user.platform_role!="platform_admin": raise HTTPException(403,"Administrator role required")
    rows=db.scalars(select(m.AuditEvent).where(m.AuditEvent.organization_id==mem.organization_id).order_by(desc(m.AuditEvent.created_at)).limit(min(limit,250))).all()
    return [{"id":x.id,"actor_id":x.actor_id,"action":x.action,"resource_type":x.resource_type,"resource_id":x.resource_id,"detail":x.detail,"created_at":x.created_at} for x in rows]

@app.get(settings.api_prefix + "/admin/metrics")
def metrics(user: m.User=Depends(current_user),db: Session=Depends(get_db)):
    mem=org_context(user,db)
    if mem.role!="lab_admin" and user.platform_role!="platform_admin": raise HTTPException(403,"Administrator role required")
    return {"cases_total":db.scalar(select(m.Case).where(m.Case.organization_id==mem.organization_id).count()) if False else len(db.scalars(select(m.Case.id).where(m.Case.organization_id==mem.organization_id)).all()),"ai_jobs_total":len(db.scalars(select(m.AIJob.id).where(m.AIJob.organization_id==mem.organization_id)).all()),"consultations_open":len(db.scalars(select(m.Consultation.id).where(m.Consultation.organization_id==mem.organization_id,m.Consultation.status=="requested")).all())}

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket, token: str):
    await ws.accept()
    try:
        uid=decode_token(token,"access")
        with SessionLocal() as db:
            user=db.get(m.User,uid)
            if not user or not user.is_active: await ws.close(code=4401); return
        await ws.send_json({"type":"connected","user_id":uid,"timestamp":datetime.now(timezone.utc).isoformat()})
        while True:
            msg=await ws.receive_json()
            # Echo acknowledgements only. Persisted chat messages use authenticated REST endpoint.
            await ws.send_json({"type":"ack","client_message_id":msg.get("client_message_id")})
    except (WebSocketDisconnect, ValueError):
        return

@app.get("/")
def root():
    return {"service":"Cytovision Backend","docs":"/docs","health":"/v1/health","research_use_only":True}
